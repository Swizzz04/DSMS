import XLSX from 'xlsx-js-style'
import { GRADING_PERIODS, WEIGHT_TABLES, transmute } from './gradingEngine'

const border = { style: 'thin', color: { rgb: '000000' } }
const allBorders = { top: border, bottom: border, left: border, right: border }

const S = {
  header: { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: 'CCECFF' } }, border: allBorders, alignment: { horizontal: 'center', vertical: 'center', wrapText: true } },
  hps: { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: 'D9D9D9' } }, border: allBorders, alignment: { horizontal: 'center' } },
  wwComp: { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: 'FFFF66' } }, border: allBorders, alignment: { horizontal: 'center' } },
  ptComp: { font: { sz: 10 }, fill: { fgColor: { rgb: '99FF66' } }, border: allBorders, alignment: { horizontal: 'center' } },
  qaComp: { font: { sz: 10 }, fill: { fgColor: { rgb: 'FF99FF' } }, border: allBorders, alignment: { horizontal: 'center' } },
  grade: { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: 'FFCC99' } }, border: allBorders, alignment: { horizontal: 'center' } },
  adjusted: { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: 'B8CCE4' } }, border: allBorders, alignment: { horizontal: 'center' } },
  markHeader: { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: 'FF0000' } }, border: allBorders, alignment: { horizontal: 'center' } },
  markFailed: { font: { color: { rgb: 'FF0000' }, sz: 10 }, border: allBorders, alignment: { horizontal: 'center' } },
  markPassed: { font: { sz: 10 }, border: allBorders, alignment: { horizontal: 'center' } },
  cell: { font: { sz: 10 }, border: allBorders, alignment: { horizontal: 'center' } },
  cellLeft: { font: { sz: 10 }, border: allBorders },
  boldCenter: { font: { bold: true, sz: 10 }, border: allBorders, alignment: { horizontal: 'center' } },
  title: { font: { bold: true, sz: 12 } },
  subtitle: { font: { bold: true, sz: 10 } },
  score: { font: { sz: 10 }, border: allBorders, alignment: { horizontal: 'center' } },
  prevQ: { font: { sz: 10, color: { rgb: '5F5F5F' } }, border: allBorders, alignment: { horizontal: 'center' } },
  summaryYellow: { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: 'FFFF99' } }, border: allBorders },
}

function setCell(ws, r, c, value, style) {
  const ref = XLSX.utils.encode_cell({ r, c })
  ws[ref] = { v: value !== undefined && value !== null ? value : '', t: typeof value === 'number' ? 'n' : 's', s: style || S.cell }
}

export function exportEClassRecord(params) {
  const { subjectName, section, gradeLevel, teacherName, schoolYear, schoolName, periodType, subjectArea, activitiesByPeriod, scoresByPeriod, students } = params
  const wb = XLSX.utils.book_new()
  const periods = GRADING_PERIODS[periodType] || GRADING_PERIODS.quarterly
  const weights = WEIGHT_TABLES[subjectArea] || { ww: 0.40, pt: 0.40, qa: 0.20 }
  const sorted = [...students].sort((a, b) => a.name.localeCompare(b.name))

  periods.forEach((period, pIdx) => {
    const acts = activitiesByPeriod[period.id] || { ww: [{ name: 'WW1', maxScore: 20 }], pt: [{ name: 'PT1', maxScore: 50 }], qa: [{ name: 'QA', maxScore: 100 }] }
    const scores = scoresByPeriod[period.id] || {}
    const wwCount = acts.ww.length, ptCount = acts.pt.length
    const C = { num: 0, id: 1, name: 2, nameEnd: 3, wwStart: 4 }
    C.wwTotal = C.wwStart + wwCount; C.wwPS = C.wwTotal + 1; C.wwWS = C.wwTotal + 2
    C.ptStart = C.wwWS + 1; C.ptTotal = C.ptStart + ptCount; C.ptPS = C.ptTotal + 1; C.ptWS = C.ptTotal + 2
    C.qa = C.ptWS + 1; C.qaPS = C.qa + 1; C.qaWS = C.qa + 2
    C.initial = C.qaWS + 1; C.qGrade = C.initial + 1; C.adjusted = C.qGrade + 1; C.mark = C.adjusted + 1
    C.prevStart = C.mark + 1
    const totalCols = C.prevStart + pIdx
    const wwMax = acts.ww.reduce((s, a) => s + (a.maxScore || 0), 0)
    const ptMax = acts.pt.reduce((s, a) => s + (a.maxScore || 0), 0)
    const qaMax = acts.qa[0]?.maxScore || 100

    const ws = {}, merges = [], range = { s: { r: 0, c: 0 }, e: { r: 0, c: totalCols - 1 } }
    const set = (r, c, v, s) => { setCell(ws, r, c, v, s); if (r > range.e.r) range.e.r = r }

    // Header info
    set(0, 1, subjectName, S.title)
    set(1, 1, section, S.subtitle)
    set(1, 4, schoolName || '', S.title)
    merges.push({ s: { r: 1, c: 4 }, e: { r: 1, c: Math.min(18, totalCols - 1) } })
    set(4, 4, section, S.subtitle); set(5, 4, subjectName, S.subtitle)
    set(6, 4, period.label, S.subtitle); set(7, 4, teacherName, S.subtitle)

    // Row 9: Header
    set(9, C.num, section, S.header); set(9, C.id, 'ID no.', S.header)
    set(9, C.name, 'STUDENT NAME', S.header); set(9, C.nameEnd, '', S.header)
    merges.push({ s: { r: 9, c: C.name }, e: { r: 9, c: C.nameEnd } })
    set(9, C.wwStart, 'WRITTEN WORK', S.header)
    if (wwCount > 1) { merges.push({ s: { r: 9, c: C.wwStart }, e: { r: 9, c: C.wwStart + wwCount - 1 } }); for (let i = 1; i < wwCount; i++) set(9, C.wwStart + i, '', S.header) }
    set(9, C.wwTotal, 'TOTAL', S.header); set(9, C.wwPS, 'PS', S.header); set(9, C.wwWS, 'WS', S.header)
    set(9, C.ptStart, 'PERFORMANCE TASKS', S.header)
    if (ptCount > 1) { merges.push({ s: { r: 9, c: C.ptStart }, e: { r: 9, c: C.ptStart + ptCount - 1 } }); for (let i = 1; i < ptCount; i++) set(9, C.ptStart + i, '', S.header) }
    set(9, C.ptTotal, 'TOTAL', S.header); set(9, C.ptPS, 'PS', S.header); set(9, C.ptWS, 'WS', S.header)
    set(9, C.qa, 'QUARTERLY\nASSESSMENT', S.header); set(9, C.qaPS, 'PS', S.header); set(9, C.qaWS, 'WS', S.header)
    set(9, C.initial, 'Initial Grade', S.header); set(9, C.qGrade, 'Quarterly Grade\n(' + period.label.split(' ')[0] + ')', S.header)
    set(9, C.adjusted, 'Adjusted Grades', S.header); set(9, C.mark, 'MARK', S.markHeader)
    for (let p = pIdx - 1; p >= 0; p--) set(9, C.prevStart + (pIdx - 1 - p), periods[p].label, S.header)

    // Row 10: Weights
    set(10, C.wwPS, 100, S.boldCenter); set(10, C.wwWS, weights.ww * 100 + '%', S.boldCenter)
    set(10, C.ptPS, 100, S.boldCenter); set(10, C.ptWS, weights.pt * 100 + '%', S.boldCenter)
    set(10, C.qaPS, 100, S.boldCenter); set(10, C.qaWS, weights.qa * 100 + '%', S.boldCenter)
    set(10, C.initial, 100, S.boldCenter); set(10, C.qGrade, 100, S.boldCenter)

    // Row 11: HPS
    set(11, C.num, '', S.hps); set(11, C.id, '', S.hps)
    set(11, C.name, 'HIGHEST POSSIBLE SCORE', S.hps); set(11, C.nameEnd, '', S.hps)
    merges.push({ s: { r: 11, c: C.name }, e: { r: 11, c: C.nameEnd } })
    for (let i = 0; i < wwCount; i++) set(11, C.wwStart + i, acts.ww[i]?.maxScore || 0, S.hps)
    set(11, C.wwTotal, wwMax, S.hps); set(11, C.wwPS, '', S.hps); set(11, C.wwWS, '', S.hps)
    for (let i = 0; i < ptCount; i++) set(11, C.ptStart + i, acts.pt[i]?.maxScore || 0, S.hps)
    set(11, C.ptTotal, ptMax, S.hps); set(11, C.ptPS, '', S.hps); set(11, C.ptWS, '', S.hps)
    set(11, C.qa, qaMax, S.hps); set(11, C.qaPS, '', S.hps); set(11, C.qaWS, '', S.hps)
    set(11, C.initial, '', S.hps); set(11, C.qGrade, '', S.hps); set(11, C.adjusted, '', S.hps); set(11, C.mark, '', S.hps)

    // Students (start row 13)
    sorted.forEach((stu, idx) => {
      const r = 13 + idx, sc = scores[stu.id] || {}
      const ww = sc.ww || [], pt = sc.pt || [], qa = sc.qa || []
      const wwS = ww.reduce((s, v) => s + (Number(v) || 0), 0), ptS = pt.reduce((s, v) => s + (Number(v) || 0), 0), qaV = Number(qa[0]) || 0
      const wwP = wwMax > 0 ? Math.round((wwS / wwMax) * 10000) / 100 : 0
      const ptP = ptMax > 0 ? Math.round((ptS / ptMax) * 10000) / 100 : 0
      const qaP = qaMax > 0 ? Math.round((qaV / qaMax) * 10000) / 100 : 0
      const wwW = Math.round(wwP * weights.ww * 100) / 100, ptW = Math.round(ptP * weights.pt * 100) / 100, qaW = Math.round(qaP * weights.qa * 100) / 100
      const ini = Math.round((wwW + ptW + qaW) * 100) / 100
      const has = ww.some(v => v !== '' && v !== 0) || pt.some(v => v !== '' && v !== 0) || qaV > 0
      const tg = has ? transmute(ini) : '', passed = tg >= 75

      set(r, C.num, idx + 1, S.cell); set(r, C.id, stu.id, S.cell)
      set(r, C.name, stu.name, S.cellLeft); set(r, C.nameEnd, '', S.cellLeft)
      merges.push({ s: { r, c: C.name }, e: { r, c: C.nameEnd } })
      for (let i = 0; i < wwCount; i++) set(r, C.wwStart + i, ww[i] !== undefined && ww[i] !== '' ? Number(ww[i]) || 0 : '', S.score)
      set(r, C.wwTotal, has ? wwS : '', S.wwComp); set(r, C.wwPS, has ? wwP : '', S.wwComp); set(r, C.wwWS, has ? wwW : '', S.wwComp)
      for (let i = 0; i < ptCount; i++) set(r, C.ptStart + i, pt[i] !== undefined && pt[i] !== '' ? Number(pt[i]) || 0 : '', S.score)
      set(r, C.ptTotal, has ? ptS : '', S.ptComp); set(r, C.ptPS, has ? ptP : '', S.ptComp); set(r, C.ptWS, has ? ptW : '', S.ptComp)
      set(r, C.qa, qaV || '', S.score); set(r, C.qaPS, has ? qaP : '', S.qaComp); set(r, C.qaWS, has ? qaW : '', S.qaComp)
      set(r, C.initial, has ? ini : '', S.grade); set(r, C.qGrade, tg, S.grade)
      set(r, C.adjusted, tg, S.adjusted)
      set(r, C.mark, has ? (passed ? 'PASSED' : 'FAILED') : '', passed ? S.markPassed : S.markFailed)

      for (let p = pIdx - 1; p >= 0; p--) {
        const ps = (scoresByPeriod[periods[p].id] || {})[stu.id], pa = activitiesByPeriod[periods[p].id] || acts
        let pg = ''
        if (ps) {
          const w = (ps.ww || []).reduce((s, v) => s + (Number(v) || 0), 0), wm = pa.ww.reduce((s, a) => s + (a.maxScore || 0), 0)
          const p2 = (ps.pt || []).reduce((s, v) => s + (Number(v) || 0), 0), pm = pa.pt.reduce((s, a) => s + (a.maxScore || 0), 0)
          const q = Number((ps.qa || [])[0]) || 0, qm = pa.qa[0]?.maxScore || 100
          pg = transmute((wm > 0 ? (w / wm) * 100 * weights.ww : 0) + (pm > 0 ? (p2 / pm) * 100 * weights.pt : 0) + (qm > 0 ? (q / qm) * 100 * weights.qa : 0))
        }
        set(r, C.prevStart + (pIdx - 1 - p), pg, S.prevQ)
      }
    })

    const footR = 13 + sorted.length + 1
    set(footR, C.name, 'Date Submitted:', S.subtitle); set(footR + 1, C.name, 'Checked By:', S.subtitle)
    ws['!ref'] = XLSX.utils.encode_range(range); ws['!merges'] = merges
    ws['!cols'] = [{ wch: 4 }, { wch: 14 }, { wch: 22 }, { wch: 10 }, ...Array(wwCount).fill({ wch: 6 }), { wch: 6 }, { wch: 7 }, { wch: 8 }, ...Array(ptCount).fill({ wch: 6 }), { wch: 5 }, { wch: 7 }, { wch: 8 }, { wch: 9 }, { wch: 8 }, { wch: 8 }, { wch: 8 }, { wch: 14 }, { wch: 10 }, { wch: 10 }]
    ws['!rows'] = []; ws['!rows'][9] = { hpt: 36 }
    XLSX.utils.book_append_sheet(wb, ws, period.label)
  })

  // Summary sheet
  const sw = {}, sm = [], sr = { s: { r: 0, c: 0 }, e: { r: 0, c: 5 + periods.length } }
  const ss = (r, c, v, s) => { setCell(sw, r, c, v, s); if (r > sr.e.r) sr.e.r = r }
  ss(1, 3, schoolName || '', S.title); ss(2, 3, 'Grading Sheet', S.subtitle)
  ss(4, 0, 'Subject Teacher:', S.subtitle); ss(4, 7, teacherName, S.summaryYellow)
  ss(5, 0, 'Grade and Section:', S.subtitle); ss(5, 7, section, S.summaryYellow)
  ss(6, 0, 'Subject:', S.subtitle); ss(6, 7, subjectName, S.summaryYellow)
  ss(8, 0, '', S.header); ss(8, 1, 'NAMES', S.header); ss(8, 2, '', S.header); ss(8, 3, '', S.header)
  sm.push({ s: { r: 8, c: 1 }, e: { r: 8, c: 3 } })
  periods.forEach((p, i) => ss(8, 4 + i, p.label.toUpperCase(), S.header))
  ss(8, 4 + periods.length, 'FINAL GRADE', S.header); ss(8, 5 + periods.length, 'REMARKS', S.header)

  sorted.forEach((stu, idx) => {
    const r = 10 + idx; ss(r, 0, idx + 1, S.cell); ss(r, 1, stu.name, S.cellLeft); ss(r, 2, '', S.cellLeft); ss(r, 3, '', S.cellLeft)
    sm.push({ s: { r, c: 1 }, e: { r, c: 3 } })
    const pg = []
    periods.forEach((period, pi) => {
      const sc = (scoresByPeriod[period.id] || {})[stu.id], ac = activitiesByPeriod[period.id] || { ww: [], pt: [], qa: [] }
      if (!sc) { ss(r, 4 + pi, '', S.cell); return }
      const w = (sc.ww || []).reduce((s, v) => s + (Number(v) || 0), 0), wm = ac.ww.reduce((s, a) => s + (a.maxScore || 0), 0)
      const p2 = (sc.pt || []).reduce((s, v) => s + (Number(v) || 0), 0), pm = ac.pt.reduce((s, a) => s + (a.maxScore || 0), 0)
      const q = Number((sc.qa || [])[0]) || 0, qm = ac.qa[0]?.maxScore || 100
      const t = transmute((wm > 0 ? (w / wm) * 100 * weights.ww : 0) + (pm > 0 ? (p2 / pm) * 100 * weights.pt : 0) + (qm > 0 ? (q / qm) * 100 * weights.qa : 0))
      ss(r, 4 + pi, t, S.cell); pg.push(t)
    })
    const v = pg.filter(g => g > 0), f = v.length > 0 ? Math.round(v.reduce((a, b) => a + b, 0) / v.length) : ''
    ss(r, 4 + periods.length, f, S.grade); ss(r, 5 + periods.length, f >= 75 ? 'PASSED' : f ? 'FAILED' : '', f >= 75 ? S.markPassed : S.markFailed)
  })

  sw['!ref'] = XLSX.utils.encode_range(sr); sw['!merges'] = sm
  sw['!cols'] = [{ wch: 4 }, { wch: 15 }, { wch: 10 }, { wch: 10 }, ...periods.map(() => ({ wch: 14 })), { wch: 14 }, { wch: 10 }]
  XLSX.utils.book_append_sheet(wb, sw, 'SUMMARY OF GRADES')

  // Transmutation Table
  const td = [['Transmutation Table','',''],[0,3.99,60],[4,7.99,61],[8,11.99,62],[12,15.99,63],[16,19.99,64],[20,23.99,65],[24,27.99,66],[28,31.99,67],[32,35.99,68],[36,39.99,69],[40,43.99,70],[44,47.99,71],[48,51.99,72],[52,55.99,73],[56,59.99,74],[60,61.59,75],[61.6,63.19,76],[63.2,64.79,77],[64.8,66.39,78],[66.4,67.99,79],[68,69.59,80],[69.6,71.19,81],[71.2,72.79,82],[72.8,74.39,83],[74.4,75.99,84],[76,77.59,85],[77.6,79.19,86],[79.2,80.79,87],[80.8,82.39,88],[82.4,83.99,89],[84,85.59,90],[85.6,87.19,91],[87.2,88.79,92],[88.8,90.39,93],[90.4,91.99,94],[92,93.59,95],[93.6,95.19,96],[95.2,96.79,97],[96.8,98.39,98],[98.4,99.99,99],[100,100,100]]
  const tw = XLSX.utils.aoa_to_sheet(td); tw['!cols'] = [{ wch: 9 }, { wch: 9 }, { wch: 9 }]
  XLSX.utils.book_append_sheet(wb, tw, 'Transmutation Table')

  const filename = 'e-Class_Record_' + subjectName.replace(/[^a-zA-Z0-9]/g, '_') + '_' + section.replace(/[^a-zA-Z0-9]/g, '_') + '_' + schoolYear + '.xlsx'
  XLSX.writeFile(wb, filename)
  return filename
}