import { useState, useEffect } from 'react'
import { Download, TrendingUp, Users, FileText, Building2, Calendar, GraduationCap, MapPin, BookOpen, Clock, CheckCircle, XCircle } from 'lucide-react'
import { Bar, Pie, Doughnut, Line } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale, LinearScale,
  BarElement, ArcElement,
  Title, Tooltip, Legend
} from 'chart.js'
import { useAuth } from '../context/AuthContext'
import { useCampusFilter } from '../context/CampusFilterContext'
import { useAppConfig } from '../context/AppConfigContext'
import { exportMultipleSheets } from '../utils/exportToExcel'
import { SkeletonDashboard } from '../components/UIComponents'
import { mockStudents } from '../data/mockStudents'
import { mockEnrollments } from '../data/mockEnrollments'

import { PointElement, LineElement } from 'chart.js'
ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, PointElement, LineElement, Title, Tooltip, Legend)

export default function Dashboard() {
  const { user } = useAuth()
  const { activeCampuses, currentSchoolYear } = useAppConfig()
  const { campusFilter = 'all' } = useCampusFilter()
  const [loading, setLoading] = useState(true)

  useEffect(() => { const t = setTimeout(() => setLoading(false), 800); return () => clearTimeout(t) }, [])
  useEffect(() => {
    setLoading(true)
    const t = setTimeout(() => setLoading(false), 500)
    return () => clearTimeout(t)
  }, [campusFilter])

  // ── Role flags ──────────────────────────────────────────────────
  const isCollegeReg = user?.role === 'registrar_college'
  const isBasicReg   = user?.role === 'registrar_basic'

  // ── Basic ed registrar: campus-locked real stats ─────────────────
  const isBasicGrade = (g) =>
    g.includes('Grade') || ['Nursery','Kindergarten','Preparatory'].some(x => g.includes(x))

  const myBasicStudents = isBasicReg
    ? mockStudents.filter(s => isBasicGrade(s.academic.gradeLevel) && s.academic.campus === user.campus)
    : []

  const myBasicEnrollments = isBasicReg
    ? mockEnrollments.filter(e => isBasicGrade(e.enrollment.gradeLevel) && e.enrollment.campus === user.campus)
    : []

  // Grade-group breakdown for basic ed registrar
  const GRADE_GROUPS = [
    { label: 'Pre-Elementary', grades: ['Nursery','Kindergarten','Preparatory'] },
    { label: 'Elementary',     grades: ['Grade 1','Grade 2','Grade 3','Grade 4','Grade 5','Grade 6'] },
    { label: 'Junior High',    grades: ['Grade 7','Grade 8','Grade 9','Grade 10'] },
    { label: 'Senior High',    grades: ['Grade 11','Grade 12'] },
  ]

  const basicGroupStats = GRADE_GROUPS.map(group => {
    const students = myBasicStudents.filter(s => group.grades.some(g => s.academic.gradeLevel === g))
    const byGrade  = group.grades.reduce((acc, g) => {
      const n = myBasicStudents.filter(s => s.academic.gradeLevel === g).length
      if (n > 0) acc[g] = n
      return acc
    }, {})
    return { ...group, total: students.length, byGrade }
  })

  const basicEnrollStats = {
    total:    myBasicEnrollments.length,
    pending:  myBasicEnrollments.filter(e => e.status === 'pending').length,
    approved: myBasicEnrollments.filter(e => e.status === 'approved').length,
    rejected: myBasicEnrollments.filter(e => e.status === 'rejected').length,
  }

  // ── College registrar: derive real stats from mock data ─────────'

  const myStudents = isCollegeReg
    ? mockStudents.filter(s => {
        const isCollege = s.academic.gradeLevel.includes('BS') || s.academic.gradeLevel.includes('Year')
        return isCollege && s.academic.campus === user.campus
      })
    : []

  const myEnrollments = isCollegeReg
    ? mockEnrollments.filter(e => {
        const isCollege = e.enrollment.gradeLevel.includes('BS') || e.enrollment.gradeLevel.includes('Year')
        return isCollege && e.enrollment.campus === user.campus
      })
    : []

  // Program → student count map
  const programStats = myStudents.reduce((acc, s) => {
    const prog = s.academic.gradeLevel.split(' - ')[0]
    if (!acc[prog]) acc[prog] = { total: 0, byYear: { '1st Year':0, '2nd Year':0, '3rd Year':0, '4th Year':0 } }
    acc[prog].total++
    const yr = s.academic.gradeLevel.split(' - ')[1] || ''
    if (acc[prog].byYear[yr] !== undefined) acc[prog].byYear[yr]++
    return acc
  }, {})

  const programList = Object.keys(programStats)

  const enrollmentStats = {
    total:    myEnrollments.length,
    pending:  myEnrollments.filter(e => e.status === 'pending').length,
    approved: myEnrollments.filter(e => e.status === 'approved').length,
    rejected: myEnrollments.filter(e => e.status === 'rejected').length,
  }

  // ── Admin / other role stats (mock) ──────────────────────────────
  const allData = {
    enrollments: { all: 1234, talisay: 567, carcar: 445, bohol: 222 },
    pending:     { all: 45,   talisay: 20,  carcar: 15,  bohol: 10 },
    students:    { all: 3567, talisay: 1678, carcar: 1234, bohol: 655 },
    revenue:     { all: 2500000, talisay: 1200000, carcar: 900000, bohol: 400000 },
  }
  const campKey = (campusFilter || 'all').toLowerCase()
  const getStats = () => ({
    enrollments: campusFilter === 'all' ? allData.enrollments.all : (allData.enrollments[campKey] ?? 0),
    pending:     campusFilter === 'all' ? allData.pending.all     : (allData.pending[campKey]     ?? 0),
    students:    campusFilter === 'all' ? allData.students.all    : (allData.students[campKey]    ?? 0),
    revenue:     campusFilter === 'all' ? allData.revenue.all     : (allData.revenue[campKey]     ?? 0),
  })
  const stats = getStats()

  const formatCurrency = (v) => new Intl.NumberFormat('en-PH', { style:'currency', currency:'PHP', minimumFractionDigits:0 }).format(v)
  const getCampusLabel = () => { if (campusFilter === 'all') return 'All Campuses'; const c = activeCampuses.find(c => c.key === campusFilter); return c ? c.name : campusFilter }

  // ── Chart options ──────────────────────────────────────────────
  const chartOpts = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { labels: { color: '#9ca3af', font: { size: 11 } } } },
    scales: { x: { ticks: { color: '#9ca3af' }, grid: { color: '#374151' } }, y: { ticks: { color: '#9ca3af' }, grid: { color: '#374151' } } },
  }
  const pieOpts = { ...chartOpts, scales: undefined, plugins: { legend: { position: 'bottom', labels: { color: '#9ca3af', padding: 12 } } } }

  // ── College registrar charts ────────────────────────────────────
  const programBarData = {
    labels: programList,
    datasets: [
      { label: '1st Year', data: programList.map(p => programStats[p].byYear['1st Year']), backgroundColor: '#750014' },
      { label: '2nd Year', data: programList.map(p => programStats[p].byYear['2nd Year']), backgroundColor: '#080c42' },
      { label: '3rd Year', data: programList.map(p => programStats[p].byYear['3rd Year']), backgroundColor: '#202682' },
      { label: '4th Year', data: programList.map(p => programStats[p].byYear['4th Year']), backgroundColor: '#6b7280' },
    ],
  }

  const enrollmentStatusData = {
    labels: ['Approved', 'Pending', 'Rejected'],
    datasets: [{ data: [enrollmentStats.approved, enrollmentStats.pending, enrollmentStats.rejected], backgroundColor: ['#10b981', '#f59e0b', '#ef4444'], borderWidth: 0 }],
  }

  // ── Admin campus comparison chart ────────────────────────────────
  const campusStudents    = { talisay: 1678, carcar: 1234, bohol: 655 }
  const campusEnrollments = { talisay: 567,  carcar: 445,  bohol: 222 }
  const shownCampuses = campusFilter === 'all' ? activeCampuses : activeCampuses.filter(c => c.key === campusFilter)
  const campusComparisonData = {
    labels: shownCampuses.map(c => c.name || c.key),
    datasets: [
      { label: 'Total Students',  data: shownCampuses.map(c => campusStudents[c.key]    || 0), backgroundColor: '#3b82f6' },
      { label: 'New Enrollments', data: shownCampuses.map(c => campusEnrollments[c.key] || 0), backgroundColor: '#10b981' },
    ],
  }
  const statusBase = campusFilter === 'all'
    ? { approved: 1089, pending: 45, rejected: 100 }
    : ({ talisay: { approved:498,pending:20,rejected:49 }, carcar:{approved:395,pending:15,rejected:35}, bohol:{approved:196,pending:10,rejected:16} }[campKey] || { approved:0,pending:0,rejected:0 })
  const statusDistributionData = {
    labels: ['Approved', 'Pending', 'Rejected'],
    datasets: [{ data: [statusBase.approved, statusBase.pending, statusBase.rejected], backgroundColor: ['#10b981','#f59e0b','#ef4444'], borderWidth: 0 }],
  }

  const handleExportExcel = () => {
    if (isCollegeReg) {
      exportMultipleSheets([
        { data: [
            { Metric: 'Campus',    Value: user.campus },
            { Metric: 'School Year', Value: currentSchoolYear },
            { Metric: 'Total Students', Value: myStudents.length },
            { Metric: 'Total Enrollments', Value: enrollmentStats.total },
            { Metric: 'Pending Enrollments', Value: enrollmentStats.pending },
            { Metric: 'Approved Enrollments', Value: enrollmentStats.approved },
          ], sheetName: 'Summary' },
        { data: myStudents.map(s => ({
            'Student ID': s.studentId,
            'Name': `${s.personal.firstName} ${s.personal.lastName}`,
            'Program': s.academic.gradeLevel,
            'Section': s.academic.section,
            'Status': s.status,
          })), sheetName: 'Students' },
        { data: myEnrollments.map(e => ({
            'Reference': e.referenceNumber,
            'Name': `${e.student.firstName} ${e.student.lastName}`,
            'Program': e.enrollment.gradeLevel,
            'Status': e.status,
            'Date': new Date(e.submittedDate).toLocaleDateString(),
          })), sheetName: 'Enrollments' },
      ], `CSHC_${user.campus.replace(/\s+/g,'_')}_College_Report_${new Date().toISOString().split('T')[0]}`)
    } else {
      exportMultipleSheets([
        { data: [
            { Metric: 'Campus', Value: getCampusLabel() },
            { Metric: 'Total Enrollments', Value: stats.enrollments },
            { Metric: 'Total Students',    Value: stats.students    },
            { Metric: 'Pending Review',    Value: stats.pending     },
            { Metric: 'Total Revenue',     Value: stats.revenue     },
          ], sheetName: 'Summary' },
        { data: shownCampuses.map((c, i) => ({
            Campus: c.name,
            'Total Students': campusStudents[c.key] || 0,
            'New Enrollments': campusEnrollments[c.key] || 0,
          })), sheetName: 'Campus Comparison' },
      ], `CSHC_Reports_${new Date().toISOString().split('T')[0]}`)
    }
  }

  if (loading) return <SkeletonDashboard />

  // ════════════════════════════════════════════════════════════════
  // COLLEGE REGISTRAR DASHBOARD
  // ════════════════════════════════════════════════════════════════
  if (isCollegeReg) {
    return (
      <div className="animate-fade-in space-y-6">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-white">
              College Registrar Dashboard
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {currentSchoolYear} · College enrollment overview
            </p>
          </div>
          <button onClick={handleExportExcel}
            className="self-start sm:self-auto flex items-center gap-1.5 px-4 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700 transition font-medium">
            <Download className="w-4 h-4" /> Export Report
          </button>
        </div>

        {/* Campus identity card */}
        <div className="bg-gradient-to-r from-secondary to-light-secondary rounded-2xl p-5 text-white shadow-lg">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-4 h-4 opacity-80" />
                <span className="text-sm font-medium opacity-80">Assigned Campus</span>
              </div>
              <h2 className="text-xl font-bold">{user.campus}</h2>
              <p className="text-sm opacity-70 mt-1">College Department · {currentSchoolYear}</p>
            </div>
            <div className="text-right">
              <p className="text-sm opacity-70">Programs offered</p>
              <p className="text-2xl font-bold">{programList.length}</p>
              <div className="flex flex-wrap justify-end gap-1 mt-2">
                {programList.map(p => (
                  <span key={p} className="text-xs bg-white/20 px-2 py-0.5 rounded-full">{p}</span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {[
            { label: 'Total Students',  value: myStudents.length,        border: 'border-primary',      icon: <Users className="w-5 h-5 text-primary"/>,         sub: 'All programs combined' },
            { label: 'Pending Review',  value: enrollmentStats.pending,  border: 'border-yellow-500',   icon: <Clock className="w-5 h-5 text-yellow-500"/>,      sub: `${enrollmentStats.total > 0 ? Math.round(enrollmentStats.pending/enrollmentStats.total*100) : 0}% of total — needs action` },
            { label: 'Approved',        value: enrollmentStats.approved, border: 'border-green-500',    icon: <CheckCircle className="w-5 h-5 text-green-500"/>, sub: `${enrollmentStats.total > 0 ? Math.round(enrollmentStats.approved/enrollmentStats.total*100) : 0}% approval rate` },
            { label: 'Total Enrollments',value: enrollmentStats.total,  border: 'border-blue-500',     icon: <FileText className="w-5 h-5 text-blue-500"/>,     sub: `${currentSchoolYear}` },
          ].map(({ label, value, border, icon, sub }) => (
            <div key={label} className={`bg-white dark:bg-gray-800 rounded-xl p-4 border-l-4 ${border} shadow-sm`}>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-gray-500 dark:text-gray-400">{label}</p>
                <div className="opacity-80">{icon}</div>
              </div>
              <p className="text-2xl font-bold text-gray-800 dark:text-white">{value}</p>
              <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{sub}</p>
            </div>
          ))}
        </div>

        {/* Program cards */}
        {programList.length > 0 && (
          <div>
            <h2 className="text-base font-semibold text-gray-700 dark:text-gray-200 mb-3 flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-primary" /> Program Overview
            </h2>
            <div className={`grid gap-4 ${programList.length === 1 ? 'grid-cols-1 max-w-sm' : programList.length === 2 ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'}`}>
              {programList.map((prog, idx) => {
                const pd = programStats[prog]
                const colors = ['bg-primary', 'bg-secondary', 'bg-light-secondary', 'bg-blue-500']
                const color = colors[idx % colors.length]
                const yearLabels = ['1st Year','2nd Year','3rd Year','4th Year']
                const maxCount = Math.max(...yearLabels.map(y => pd.byYear[y]))
                return (
                  <div key={prog} className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
                    <div className={`${color} px-5 py-4 text-white`}>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-xs font-medium opacity-80 uppercase tracking-wider">Program</p>
                          <h3 className="text-lg font-bold leading-tight mt-0.5">{prog}</h3>
                        </div>
                        <div className="text-right">
                          <p className="text-3xl font-bold">{pd.total}</p>
                          <p className="text-xs opacity-80">students</p>
                        </div>
                      </div>
                    </div>
                    <div className="p-4 space-y-2">
                      {yearLabels.map(yr => (
                        <div key={yr} className="flex items-center gap-3">
                          <span className="text-xs text-gray-500 dark:text-gray-400 w-14 flex-shrink-0">{yr}</span>
                          <div className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${color} transition-all duration-500`}
                              style={{ width: maxCount > 0 ? `${(pd.byYear[yr] / maxCount) * 100}%` : '0%' }}
                            />
                          </div>
                          <span className="text-xs font-semibold text-gray-700 dark:text-gray-300 w-5 text-right">
                            {pd.byYear[yr] || 0}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Charts row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Students by program bar chart */}
          {programList.length > 0 && (
            <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
              <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-200 mb-4">Students by Program & Year</h3>
              <div style={{ height: 240 }}>
                <Bar data={programBarData} options={{ ...chartOpts, scales: { ...chartOpts.scales, x: { ...chartOpts.scales.x, stacked: false }, y: { ...chartOpts.scales.y, stacked: false, beginAtZero: true } } }} />
              </div>
            </div>
          )}

          {/* Enrollment status donut */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-200 mb-4">Enrollment Status Distribution</h3>
            {enrollmentStats.total > 0 ? (
              <div style={{ height: 240 }} className="flex items-center justify-center">
                <Doughnut data={enrollmentStatusData} options={pieOpts} />
              </div>
            ) : (
              <div className="flex items-center justify-center h-60 text-sm text-gray-400">No enrollment data yet</div>
            )}
          </div>
        </div>

        {/* Recent enrollments table */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-200 flex items-center gap-2">
              <FileText className="w-4 h-4 text-primary" /> Recent Enrollment Applications
            </h3>
            <span className="text-xs text-gray-400">{myEnrollments.length} total</span>
          </div>
          {myEnrollments.length === 0 ? (
            <div className="px-5 py-12 text-center text-sm text-gray-400">No enrollment applications found for your campus.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 dark:bg-gray-700/50">
                  <tr>
                    {['Reference', 'Student Name', 'Program & Year', 'Type', 'Status', 'Date'].map(h => (
                      <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                  {myEnrollments.map(e => (
                    <tr key={e.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30">
                      <td className="px-4 py-3 font-mono text-xs text-primary dark:text-red-400 whitespace-nowrap">{e.referenceNumber}</td>
                      <td className="px-4 py-3 font-medium text-gray-800 dark:text-white whitespace-nowrap">{e.student.firstName} {e.student.lastName}</td>
                      <td className="px-4 py-3 text-gray-600 dark:text-gray-300 whitespace-nowrap">{e.enrollment.gradeLevel}</td>
                      <td className="px-4 py-3 text-gray-500 dark:text-gray-400 whitespace-nowrap">{e.enrollment.studentType}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <StatusDot status={e.status} />
                      </td>
                      <td className="px-4 py-3 text-gray-500 dark:text-gray-400 whitespace-nowrap text-xs">
                        {new Date(e.submittedDate).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    )
  }

  // ════════════════════════════════════════════════════════════════
  // BASIC ED REGISTRAR DASHBOARD
  // ════════════════════════════════════════════════════════════════
  if (isBasicReg) {
    const groupColors = [
      { bg: 'bg-emerald-600', light: 'bg-emerald-100 dark:bg-emerald-900/30', text: 'text-emerald-700 dark:text-emerald-300', bar: '#059669' },
      { bg: 'bg-blue-600',   light: 'bg-blue-100 dark:bg-blue-900/30',       text: 'text-blue-700 dark:text-blue-300',       bar: '#2563eb' },
      { bg: 'bg-secondary',  light: 'bg-indigo-100 dark:bg-indigo-900/30',   text: 'text-indigo-700 dark:text-indigo-300',   bar: '#080c42' },
      { bg: 'bg-primary',    light: 'bg-red-100 dark:bg-red-900/30',         text: 'text-primary dark:text-red-300',         bar: '#750014' },
    ]

    const groupBarData = {
      labels: basicGroupStats.map(g => g.label),
      datasets: [{
        label: 'Students',
        data: basicGroupStats.map(g => g.total),
        backgroundColor: groupColors.map(c => c.bar),
        borderRadius: 6,
      }],
    }

    const enrollmentStatusData = {
      labels: ['Approved', 'Pending', 'Rejected'],
      datasets: [{ data: [basicEnrollStats.approved, basicEnrollStats.pending, basicEnrollStats.rejected], backgroundColor: ['#10b981','#f59e0b','#ef4444'], borderWidth: 0 }],
    }

    const handleBasicExport = () => {
      exportMultipleSheets([
        { data: [
            { Metric: 'Campus',              Value: user.campus },
            { Metric: 'School Year',         Value: currentSchoolYear },
            { Metric: 'Total Students',      Value: myBasicStudents.length },
            { Metric: 'Total Enrollments',   Value: basicEnrollStats.total },
            { Metric: 'Pending',             Value: basicEnrollStats.pending },
            { Metric: 'Approved',            Value: basicEnrollStats.approved },
          ], sheetName: 'Summary' },
        { data: myBasicStudents.map(s => ({
            'Student ID': s.studentId,
            'Name': `${s.personal.firstName} ${s.personal.lastName}`,
            'Grade Level': s.academic.gradeLevel,
            'Section': s.academic.section,
            'Status': s.status,
          })), sheetName: 'Students' },
        { data: myBasicEnrollments.map(e => ({
            'Reference': e.referenceNumber,
            'Name': `${e.student.firstName} ${e.student.lastName}`,
            'Grade Level': e.enrollment.gradeLevel,
            'Type': e.enrollment.studentType,
            'Status': e.status,
            'Date': new Date(e.submittedDate).toLocaleDateString(),
          })), sheetName: 'Enrollments' },
      ], `CSHC_${user.campus.replace(/\s+/g,'_')}_BasicEd_Report_${new Date().toISOString().split('T')[0]}`)
    }

    return (
      <div className="animate-fade-in space-y-6">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-white">
              Basic Education Dashboard
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {currentSchoolYear} · Pre-Elementary to Senior High School
            </p>
          </div>
          <button onClick={handleBasicExport}
            className="self-start sm:self-auto flex items-center gap-1.5 px-4 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700 transition font-medium">
            <Download className="w-4 h-4" /> Export Report
          </button>
        </div>

        {/* Campus identity card */}
        <div className="bg-gradient-to-r from-emerald-700 to-emerald-500 rounded-2xl p-5 text-white shadow-lg">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-4 h-4 opacity-80" />
                <span className="text-sm font-medium opacity-80">Assigned Campus</span>
              </div>
              <h2 className="text-xl font-bold">{user.campus}</h2>
              <p className="text-sm opacity-70 mt-1">Basic Education Department · {currentSchoolYear}</p>
            </div>
            <div className="text-right flex-shrink-0">
              <p className="text-sm opacity-70">Grade levels</p>
              <p className="text-3xl font-bold">15</p>
              <p className="text-xs opacity-70 mt-0.5">Nursery → Grade 12</p>
            </div>
          </div>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {[
            { label: 'Total Students',     value: myBasicStudents.length,        border: 'border-emerald-500', icon: <Users className="w-5 h-5 text-emerald-500"/>,       sub: 'All grade levels' },
            { label: 'Pending Review',     value: basicEnrollStats.pending,      border: 'border-yellow-500',  icon: <Clock className="w-5 h-5 text-yellow-500"/>,        sub: `${basicEnrollStats.total > 0 ? Math.round(basicEnrollStats.pending/basicEnrollStats.total*100) : 0}% of total` },
            { label: 'Approved',           value: basicEnrollStats.approved,     border: 'border-green-500',   icon: <CheckCircle className="w-5 h-5 text-green-500"/>,   sub: `${basicEnrollStats.total > 0 ? Math.round(basicEnrollStats.approved/basicEnrollStats.total*100) : 0}% approval rate` },
            { label: 'Total Enrollments',  value: basicEnrollStats.total,        border: 'border-blue-500',    icon: <FileText className="w-5 h-5 text-blue-500"/>,       sub: currentSchoolYear },
          ].map(({ label, value, border, icon, sub }) => (
            <div key={label} className={`bg-white dark:bg-gray-800 rounded-xl p-4 border-l-4 ${border} shadow-sm`}>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-gray-500 dark:text-gray-400">{label}</p>
                <div className="opacity-80">{icon}</div>
              </div>
              <p className="text-2xl font-bold text-gray-800 dark:text-white">{value}</p>
              <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{sub}</p>
            </div>
          ))}
        </div>

        {/* Grade group cards */}
        <div>
          <h2 className="text-base font-semibold text-gray-700 dark:text-gray-200 mb-3 flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-emerald-600" /> Students by Department
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {basicGroupStats.map((group, idx) => {
              const col = groupColors[idx]
              const maxVal = Math.max(...Object.values(group.byGrade), 1)
              return (
                <div key={group.label} className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
                  <div className={`${col.bg} px-4 py-3 text-white`}>
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold uppercase tracking-wider opacity-90">{group.label}</p>
                      <span className="text-2xl font-bold">{group.total}</span>
                    </div>
                  </div>
                  <div className="p-3 space-y-1.5">
                    {group.grades.map(g => {
                      const count = group.byGrade[g] || 0
                      return (
                        <div key={g} className="flex items-center gap-2">
                          <span className="text-xs text-gray-500 dark:text-gray-400 w-20 truncate flex-shrink-0">{g}</span>
                          <div className="flex-1 bg-gray-100 dark:bg-gray-700 rounded-full h-1.5 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${col.bg} opacity-80`}
                              style={{ width: count > 0 ? `${(count/maxVal)*100}%` : '0%' }}
                            />
                          </div>
                          <span className={`text-xs font-bold w-4 text-right ${count > 0 ? col.text : 'text-gray-300 dark:text-gray-600'}`}>
                            {count || '—'}
                          </span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Charts row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-200 mb-4">Students by Department</h3>
            <div style={{ height: 220 }}>
              <Bar data={groupBarData} options={{ ...chartOpts, plugins: { legend: { display: false } }, scales: { ...chartOpts.scales, y: { ...chartOpts.scales.y, beginAtZero: true } } }} />
            </div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-200 mb-4">Enrollment Status</h3>
            {basicEnrollStats.total > 0 ? (
              <div style={{ height: 220 }} className="flex items-center justify-center">
                <Doughnut data={enrollmentStatusData} options={pieOpts} />
              </div>
            ) : (
              <div className="flex items-center justify-center h-56 text-sm text-gray-400">No enrollment data</div>
            )}
          </div>
        </div>

        {/* Recent enrollments */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-200 flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-600" /> Recent Enrollment Applications
            </h3>
            <span className="text-xs text-gray-400">{myBasicEnrollments.length} total</span>
          </div>
          {myBasicEnrollments.length === 0 ? (
            <p className="px-5 py-10 text-center text-sm text-gray-400">No enrollment applications found for your campus.</p>
          ) : (
            <>
              {/* Mobile cards */}
              <ul className="md:hidden divide-y divide-gray-100 dark:divide-gray-700">
                {myBasicEnrollments.slice(0, 8).map(e => (
                  <li key={e.id} className="px-4 py-3 flex items-start gap-3">
                    <div className="w-8 h-8 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <GraduationCap className="w-4 h-4 text-emerald-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-sm font-medium text-gray-800 dark:text-white truncate">{e.student.firstName} {e.student.lastName}</p>
                        <StatusDot status={e.status} />
                      </div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{e.enrollment.gradeLevel} · {e.enrollment.studentType}</p>
                      <p className="text-xs font-mono text-emerald-600 dark:text-emerald-400">{e.referenceNumber}</p>
                    </div>
                  </li>
                ))}
              </ul>
              {/* Desktop table */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 dark:bg-gray-700/50">
                    <tr>
                      {['Reference','Student Name','Grade Level','Student Type','Status','Date Submitted'].map(h => (
                        <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                    {myBasicEnrollments.map(e => (
                      <tr key={e.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30">
                        <td className="px-4 py-3 font-mono text-xs text-emerald-600 dark:text-emerald-400 whitespace-nowrap">{e.referenceNumber}</td>
                        <td className="px-4 py-3 font-medium text-gray-800 dark:text-white whitespace-nowrap">{e.student.firstName} {e.student.lastName}</td>
                        <td className="px-4 py-3 text-gray-600 dark:text-gray-300 whitespace-nowrap">{e.enrollment.gradeLevel}</td>
                        <td className="px-4 py-3 text-gray-500 dark:text-gray-400 whitespace-nowrap">{e.enrollment.studentType}</td>
                        <td className="px-4 py-3 whitespace-nowrap"><StatusDot status={e.status} /></td>
                        <td className="px-4 py-3 text-gray-500 dark:text-gray-400 whitespace-nowrap text-xs">
                          {new Date(e.submittedDate).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      </div>
    )
  }

  // ════════════════════════════════════════════════════════════════
  // ADMIN / OTHER ROLES DASHBOARD
  // ════════════════════════════════════════════════════════════════
  return (
    <div className="animate-fade-in">
      <div className="mb-6 flex items-start justify-between">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 dark:text-white">
            {user?.role === 'admin'             && 'Admin Dashboard'}
            {user?.role === 'registrar_basic'   && 'Basic Education Dashboard'}
            {user?.role === 'accounting'         && 'Accounting Dashboard'}
            {user?.role === 'principal_basic'    && 'Basic Education Principal Dashboard'}
          </h1>
          <p className="text-gray-600 dark:text-gray-400 text-sm mt-1">
            {user?.role === 'admin'           && 'Overview of school operations and statistics'}
            {user?.role === 'registrar_basic' && 'Basic Education enrollment overview'}
            {user?.role === 'accounting'       && 'Financial overview and payment tracking'}
            {user?.role === 'principal_basic'  && 'Basic Education student and academic overview'}
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={handleExportExcel} className="px-3 py-1.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition flex items-center gap-1.5 text-sm">
            <Download className="w-4 h-4" /> Excel
          </button>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
        {[
          { label:'Total Enrollments', value: stats.enrollments.toLocaleString(), border:'border-primary',     icon:'📋', sub: getCampusLabel() },
          { label:'Pending Review',    value: stats.pending.toLocaleString(),     border:'border-yellow-500',  icon:'⏳', sub: `${stats.enrollments > 0 ? Math.round((stats.pending/stats.enrollments)*100) : 0}% pending` },
          { label:'Total Students',    value: stats.students.toLocaleString(),    border:'border-green-500',   icon:'👥', sub: getCampusLabel() },
          { label:'Revenue',           value: formatCurrency(stats.revenue),      border:'border-blue-500',    icon:'💰', sub: getCampusLabel() },
        ].map(({ label, value, border, icon, sub }) => (
          <div key={label} className={`bg-white dark:bg-gray-800 rounded-lg p-4 sm:p-6 border-l-4 ${border} shadow-lg transform hover:scale-105 transition-transform`}>
            <div className="flex items-center justify-between">
              <div><p className="text-sm text-gray-500 dark:text-gray-400 mb-1">{label}</p><h3 className="text-xl sm:text-2xl font-bold text-gray-800 dark:text-white">{value}</h3></div>
              <div className="w-12 h-12 bg-gray-50 dark:bg-gray-700 rounded-full flex items-center justify-center"><span className="text-2xl">{icon}</span></div>
            </div>
            <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">{sub}</p>
          </div>
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mb-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">{campusFilter === 'all' ? 'Campus Comparison' : `${getCampusLabel()} — Students`}</h3>
          <div style={{ height: 300 }}><Bar data={campusComparisonData} options={chartOpts} /></div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">Enrollment Status Distribution</h3>
          <div style={{ height: 300 }} className="flex items-center justify-center">
            <Pie data={statusDistributionData} options={pieOpts} />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Campus Statistics</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                {['Campus', 'Total Students', 'New Enrollments', 'Pending', 'Approval Rate'].map(h => (
                  <th key={h} className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {(campusFilter === 'all' ? activeCampuses : activeCampuses.filter(c => c.key === campusFilter)).map((campus) => {
                const s = { talisay:{students:1678,enrollments:567,pending:20,approval:'89%'}, carcar:{students:1234,enrollments:445,pending:15,approval:'91%'}, bohol:{students:655,enrollments:222,pending:10,approval:'85%'} }[campus.key] || { students:0,enrollments:0,pending:0,approval:'N/A' }
                return (
                  <tr key={campus.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                    <td className="px-6 py-4 text-sm font-medium text-gray-800 dark:text-white">{campus.name}</td>
                    <td className="px-6 py-4 text-sm text-gray-600 dark:text-gray-300">{s.students.toLocaleString()}</td>
                    <td className="px-6 py-4 text-sm text-gray-600 dark:text-gray-300">{s.enrollments.toLocaleString()}</td>
                    <td className="px-6 py-4 text-sm text-gray-600 dark:text-gray-300">{s.pending}</td>
                    <td className="px-6 py-4 text-sm"><span className="text-green-600 dark:text-green-400 font-semibold">{s.approval}</span></td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function StatusDot({ status }) {
  const map = {
    pending:  { cls: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400', icon: <Clock className="w-3 h-3" />, label: 'Pending' },
    approved: { cls: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',  icon: <CheckCircle className="w-3 h-3" />, label: 'Approved' },
    rejected: { cls: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',          icon: <XCircle className="w-3 h-3" />, label: 'Rejected' },
  }
  const cfg = map[status] || map.pending
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${cfg.cls}`}>
      {cfg.icon}{cfg.label}
    </span>
  )
}